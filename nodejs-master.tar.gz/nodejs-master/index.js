'use strict';
require('babel-core/register');
console.log('app started');
